export { default } from "./picture";
