export { default } from "./gallery";
