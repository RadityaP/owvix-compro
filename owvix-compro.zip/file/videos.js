export const creativeVideos = [
  {
    src: "https://img.youtube.com/vi/Rk8_ZbSKZ0E/maxresdefault.jpg",
    title: "FILM PENDEK - SUDUT MAKNA",
    videoId: "Rk8_ZbSKZ0E",
  },
  {
    src: "https://img.youtube.com/vi/lkBLdqmEeSI/hqdefault.jpg",
    title: "Company Profile Alisa City Nagreg",
    videoId: "lkBLdqmEeSI",
  },
  {
    src: "https://img.youtube.com/vi/iWNeURbyW2c/maxresdefault.jpg",
    title: "HIGHLIGHT PERLOMBAAN HAKORDIA 2021",
    videoId: "iWNeURbyW2c",
  },
  {
    src: "https://img.youtube.com/vi/rAndUNcI8Rw/maxresdefault.jpg",
    title: "HIGHLIGHT EVENT SAVARAVAT",
    videoId: "rAndUNcI8Rw",
  },
  {
    src: "https://img.youtube.com/vi/nj7r1TROFnI/maxresdefault.jpg",
    title: "D3 Perhotelan Telkom University Goes to Bali",
    videoId: "nj7r1TROFnI",
  },
  {
    src: "https://img.youtube.com/vi/XSi4Aw0y--c/maxresdefault.jpg",
    title: "AFTERMOVIE YEAR BOOK SMA PLUS SOREANG",
    videoId: "XSi4Aw0y--c",
  },
  {
    src: "https://img.youtube.com/vi/Aw1fJJTaLy8/maxresdefault.jpg",
    title: "RECAP - KONSER INTERN - KAWALA PSM UNPAD - ONLINE",
    videoId: "Aw1fJJTaLy8",
  },
  {
    src: "https://img.youtube.com/vi/A2O1P7MbnTk/maxresdefault.jpg",
    title: "AFTERMOVIE SUMPAH APOTEKER UNPAD 2022",
    videoId: "A2O1P7MbnTk",
  },
  {
    src: "https://img.youtube.com/vi/Lkgu0ZvrWJo/maxresdefault.jpg",
    title: "Family Gathering PT Meiyume",
    videoId: "Lkgu0ZvrWJo",
  },
];

export const momentVideos = [
  {
    src: "https://img.youtube.com/vi/4_B8112mGSw/maxresdefault.jpg",
    title: "Aftermovie Gathering Swissbel-Resort Dago Goes to Pangandaran",
    videoId: "4_B8112mGSw",
  },
  {
    src: "https://img.youtube.com/vi/d2KNYDW9Cyo/maxresdefault.jpg",
    title: "Aftermovie - Family Gathering PT Mutiara Jawa",
    videoId: "d2KNYDW9Cyo",
  },
  {
    src: "https://img.youtube.com/vi/9GymUilo5xs/maxresdefault.jpg",
    title: "Wedding Safitriyani & Ramadhan",
    videoId: "9GymUilo5xs",
  },
  {
    src: "https://img.youtube.com/vi/YZcy7MWYWqk/maxresdefault.jpg",
    title: "The Wedding of Sera Alie",
    videoId: "YZcy7MWYWqk",
  },
  {
    src: "https://img.youtube.com/vi/0ETwvfJu2FA/maxresdefault.jpg",
    title: "ENGAGEMENT TRIAH & ROBI",
    videoId: "0ETwvfJu2FA",
  },
  {
    src: "https://img.youtube.com/vi/x87xCxl0Bn0/maxresdefault.jpg",
    title: "Engagement of Nadhila & Adil",
    videoId: "x87xCxl0Bn0",
  },
  {
    src: "https://img.youtube.com/vi/R_oopksH_IA/maxresdefault.jpg",
    title: "Engagement Safitriyani & Ramadhan",
    videoId: "R_oopksH_IA",
  },
  {
    src: "https://img.youtube.com/vi/SpKD752-pGI/maxresdefault.jpg",
    title: "Wisuda Sumpah Apoteker - Apt. Kezia, S. Farm.",
    videoId: "SpKD752-pGI",
  },
  {
    src: "https://img.youtube.com/vi/8MSpxN6Tww4/maxresdefault.jpg",
    title: "Wisuda Idvan A Bintara, S Pd - Matematika UPI",
    videoId: "8MSpxN6Tww4",
  },
];
