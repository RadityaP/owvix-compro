"use strict";
exports.id = 229;
exports.ids = [229];
exports.modules = {

/***/ 6229:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* reexport */ youtube)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react-youtube"
var external_react_youtube_ = __webpack_require__(9294);
var external_react_youtube_default = /*#__PURE__*/__webpack_require__.n(external_react_youtube_);
;// CONCATENATED MODULE: ./components/specific/youtube/player.js



const YoutubePlayer = ({ videoId , setShowPlayer , setPlayVideo  })=>{
    const opts = {
        playerVars: {
            // https://developers.google.com/youtube/player_parameters
            autoplay: 1
        }
    };
    const onReady = (event)=>{
    // access to player in all event handlers via event.target
    // event.target.pauseVideo();
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        style: {
            textAlign: "center"
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_youtube_default()), {
            videoId: videoId,
            opts: opts,
            onReady: onReady,
            iframeClassName: "w-[350px] md:w-[900px] h-[195px] md:h-[506px] aspect-[800/450]"
        })
    });
};
/* harmony default export */ const player = (YoutubePlayer);

;// CONCATENATED MODULE: ./components/specific/youtube/thumbnail.js




const Thumbnail = (props)=>{
    const { src , title , videoId , playedVideo , setPlayedVideo  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "w-full inline-block",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: `${playedVideo === videoId ? "hidden" : "block"} relative w-full aspect-[800/450] border-4 border-white border-solid m-auto cursor-pointer hover:opacity-60 duration-500 ease-in-out`,
                onClick: ()=>{
                    setPlayedVideo(videoId);
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: src,
                        alt: title,
                        layout: "fill",
                        objectFit: "contain",
                        loading: "lazy"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "absolute top-[50%] left-[50%] translate-y-[-50%] translate-x-[-50%]",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: "https://owvix.com/images/assets/play-button-colored.png",
                            alt: "asdad",
                            height: 70,
                            width: 70
                        })
                    })
                ]
            }),
            playedVideo === videoId && /*#__PURE__*/ jsx_runtime_.jsx(player, {
                videoId: videoId
            })
        ]
    });
};
/* harmony default export */ const thumbnail = (Thumbnail);

// EXTERNAL MODULE: ./styles/galeri.module.css
var galeri_module = __webpack_require__(8747);
var galeri_module_default = /*#__PURE__*/__webpack_require__.n(galeri_module);
;// CONCATENATED MODULE: ./components/specific/youtube/youtube.js





const Youtube = ({ videos , showTitle  })=>{
    const { 0: index , 1: setIndex  } = (0,external_react_.useState)(0);
    const { 0: playedVideo , 1: setPlayedVideo  } = (0,external_react_.useState)("");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `${(galeri_module_default())["arrow-container"]} ${(galeri_module_default()).left}`,
                style: {
                    opacity: index === 0 ? 0 : 1
                },
                onClick: ()=>{
                    if (index !== 0) {
                        setIndex(index - 1);
                        setPlayedVideo("");
                    }
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: "https://owvix.com/images/assets/chevron-pointing-to-the-left.png",
                    alt: "asdad",
                    height: 14,
                    width: 14
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "overflow-hidden max-w-[1000px] w-full",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "whitespace-nowrap duration-1000 w-full ease-in-out",
                    style: {
                        transform: `translate3d(${-index * 100}%, 0, 0)`
                    },
                    children: videos.map((thumb, index)=>{
                        return /*#__PURE__*/ jsx_runtime_.jsx(thumbnail, {
                            src: thumb.src,
                            title: thumb.title,
                            videoId: thumb.videoId,
                            playedVideo: playedVideo,
                            setPlayedVideo: setPlayedVideo
                        }, index);
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                style: {
                    opacity: index === videos.length - 1 ? 0 : 1
                },
                className: `${(galeri_module_default())["arrow-container"]} ${(galeri_module_default()).right}`,
                onClick: ()=>{
                    if (index !== videos.length - 1) {
                        setIndex(index + 1);
                        setPlayedVideo("");
                    }
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: "https://owvix.com/images/assets/right-chevron.png",
                    alt: "asdad",
                    height: 14,
                    width: 14
                })
            })
        ]
    });
};
/* harmony default export */ const youtube = (Youtube);

;// CONCATENATED MODULE: ./components/specific/youtube/index.js



/***/ })

};
;