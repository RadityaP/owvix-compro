export { default } from "./name";
