"use strict";
exports.id = 166;
exports.ids = [166];
exports.modules = {

/***/ 4264:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* reexport */ container)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./components/global/navbar/navbar.js





const NavigationList = [
    {
        id: "home",
        title: "Home",
        link: "/"
    },
    {
        id: "about",
        title: "About",
        link: "/about"
    },
    {
        id: "clients",
        title: "Clients",
        link: "/clients"
    }, 
];
const Navbar = ()=>{
    const { 0: menuOpened , 1: setMenuOpened  } = (0,external_react_.useState)(false);
    const router = (0,router_.useRouter)();
    return /*#__PURE__*/ jsx_runtime_.jsx("nav", {
        className: "bg-black border-b-2 border-b-gray-400 border-0 border-solid",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container px-7 md:px-10 max-w-[1280px] flex flex-wrap justify-between items-center mx-auto",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/",
                    className: "flex items-center text-white text-3xl",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-[70px] h-[70px] md:w-[100px] md:h-[100px] relative cursor-pointer",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: "https://owvix.com/images/assets/logo-white.png",
                            alt: "logo",
                            layout: "fill",
                            objectFit: "contain",
                            loading: "eager"
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "relative w-[24px] h-[24px] cursor-pointer flex md:hidden flex-col gap-[5px]",
                    onClick: ()=>setMenuOpened(!menuOpened),
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "w-full h-[3px] md:h-[4px] bg-white rounded-full"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "w-full h-[3px] md:h-[4px] bg-white rounded-full"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "w-full h-[3px] md:h-[4px] bg-white rounded-full"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: `${menuOpened ? "block" : "hidden"} w-full md:block md:w-auto`,
                    id: "mobile-menu",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                        className: "flex flex-col p-4 mt-4 mb-0 rounded-lg border border-gray-100 md:flex-row md:space-x-8 md:mt-0 md:text-sm md:font-medium md:border-0",
                        children: NavigationList.map((list)=>{
                            return /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "list-none",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: list.link,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: `${list.link === router.pathname ? "text-red-primary after:!left-0" : ""} text-center md:text-left block text-lg font-bold py-2 pr-4 pl-3 text-white hover:text-red-primary transition-all duration-300 after:transition-all relative overflow-hidden after:duration-300 after:content-[''] after:w-full after:h-[2px] after:bg-red-primary after:absolute after:bottom-0 after:left-[-1020px] md:after:left-[-150px] hover:after:left-0`,
                                        children: list.title
                                    })
                                })
                            }, list.id);
                        })
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const navbar = (Navbar);

;// CONCATENATED MODULE: ./components/global/navbar/index.js


;// CONCATENATED MODULE: ./components/global/button/scrollToTopButton.js



const ScrollToTopButton = ()=>{
    const { 0: offset , 1: setOffset  } = (0,external_react_.useState)(0);
    (0,external_react_.useEffect)(()=>{
        const onScroll = ()=>setOffset(window.pageYOffset);
        window.removeEventListener("scroll", onScroll);
        window.addEventListener("scroll", onScroll, {
            passive: true
        });
        return ()=>window.removeEventListener("scroll", onScroll);
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        onClick: ()=>window.scrollTo({
                top: 0,
                behavior: "smooth"
            }),
        className: `${offset >= 100 ? "opacity-1" : "opacity-0"} fixed bottom-[20px] right-[20px] w-10 h-10 bg-gray-400 rounded-lg flex items-center justify-center cursor-pointer hover:bg-gray-200 transition-all duration-300`,
        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
            src: "https://owvix.com/images/assets/chevron-arrow-up.png",
            alt: "chevron top",
            height: 20,
            width: 20
        })
    });
};
/* harmony default export */ const scrollToTopButton = (ScrollToTopButton);

;// CONCATENATED MODULE: ./components/global/footer/footer.js


const Footer = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "bg-black flex text-[12px] md:text-[16px] items-center justify-center py-5 border-0 border-t-[3px] border-t-gray-400 border-solid text-white font-semibold",
        children: "\xa9 2022 by Owvixcreative"
    });
};
/* harmony default export */ const footer = (Footer);

;// CONCATENATED MODULE: ./components/global/footer/index.js


;// CONCATENATED MODULE: ./components/global/container/container.js






const Container = (props)=>{
    const { title , background  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Owvix Photography was formed with limited resources, but was able to produce a great output that could compete in the creative agency industry in West Java"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        charset: "utf-8"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "keywords",
                        content: "photography, agency, creative"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "robots",
                        content: "follow"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(navbar, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `flex justify-center flex-col bg-${background}`,
                children: props.children
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(scrollToTopButton, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(footer, {})
        ]
    });
};
/* harmony default export */ const container = (Container);

;// CONCATENATED MODULE: ./components/global/container/index.js



/***/ }),

/***/ 7736:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const Section = (props)=>{
    const { text  } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: `flex justify-center py-8 md:py-10`,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: `md:max-w-[1280px] w-full px-7 md:px-10 text-${text}`,
            children: props.children
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Section);


/***/ })

};
;