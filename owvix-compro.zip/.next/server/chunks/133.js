"use strict";
exports.id = 133;
exports.ids = [133];
exports.modules = {

/***/ 6133:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* reexport */ picture)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/specific/about/name/name.js


const Index = ({ name , title  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "mt-3 text-center md:text-left",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "text-[24px] md:text-[40px] font-bold",
                children: name
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "text-[12px] md:text-[20px] font-normal italic",
                children: title
            })
        ]
    });
};
/* harmony default export */ const name_name = (Index);

;// CONCATENATED MODULE: ./components/specific/about/name/index.js


;// CONCATENATED MODULE: ./components/specific/about/picture/picture.js




const picture_Index = ({ image , isRight , name , title  })=>{
    return isRight ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "basis-6/12 h-fit md:pl-16 flex flex-col items-center md:items-start h-auto",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-8/12 md:w-full aspect-2/3 relative",
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: image === "rinaldy" ? "https://owvix.com/images/assets/about/rinaldy.jpeg" : image === "salman" ? "https://owvix.com/images/assets/about/salman.jpeg" : image === "sham" ? "https://owvix.com/images/assets/about/shammil.jpeg" : image === "nanda" ? "https://owvix.com/images/assets/about/nanda.jpg" : image === "temy" ? "https://owvix.com/images/assets/about/temy.jpeg" : image === "tsamara" ? "https://owvix.com/images/assets/about/tsamara.jpeg" : "https://owvix.com/images/assets/about/jo.jpg",
                    layout: "fill",
                    objectFit: "contain",
                    alt: "logo",
                    loading: "lazy",
                    placeholder: "blur",
                    blurDataURL: "data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs="
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(name_name, {
                name: name,
                title: title
            })
        ]
    }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "basis-6/12 h-fit md:pr-16 pb-16 md:pb-0 flex flex-col items-center md:items-start h-auto",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-8/12 md:w-full aspect-2/3 relative",
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: image === "rinaldy" ? "https://owvix.com/images/assets/about/rinaldy.jpeg" : image === "salman" ? "https://owvix.com/images/assets/about/salman.jpeg" : image === "sham" ? "https://owvix.com/images/assets/about/shammil.jpeg" : image === "nanda" ? "https://owvix.com/images/assets/about/nanda.jpg" : image === "temy" ? "https://owvix.com/images/assets/about/temy.jpeg" : image === "tsamara" ? "https://owvix.com/images/assets/about/tsamara.jpeg" : "https://owvix.com/images/assets/about/jo.jpg",
                    layout: "fill",
                    objectFit: "contain",
                    alt: "logo",
                    loading: "lazy",
                    placeholder: "blur",
                    blurDataURL: "data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs="
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(name_name, {
                name: name,
                title: title
            })
        ]
    });
};
/* harmony default export */ const picture = (picture_Index);

;// CONCATENATED MODULE: ./components/specific/about/picture/index.js



/***/ })

};
;